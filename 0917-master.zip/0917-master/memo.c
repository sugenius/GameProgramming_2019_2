//memo.c

#include "diary.h"
void memo() {
printf("Show memo.c \n");
}
